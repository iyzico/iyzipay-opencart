<?php
// Text
$_['pwi_title'] = 'Pay with iyzico';
$_['pwi_img_title'] 			= '<img width="20%" src="admin/view/image/payment/pay-with-iyzico.svg"/>';
$_['payment_failed'] 		 	= 'Payment Failed';
$_['payment_field_desc'] 	 	= 'Payment ID: ';
$_['installement_field_desc'] 	= ' Installement ';