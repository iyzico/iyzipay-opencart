<?php
// Text
$_['pwi_title'] = 'iyzico ile Öde';
$_['pwi_img_title'] 			= '<img width="20%" src="admin/view/image/payment/pay-with-iyzico-tr.svg"/>';
$_['payment_failed'] 		  	= 'Ödeme Başarısız';
$_['payment_field_desc'] 	 	= 'Ödeme Numarası: ';
$_['installement_field_desc'] 	= ' Taksit ';